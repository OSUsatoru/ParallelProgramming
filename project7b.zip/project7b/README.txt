module load slurm
module load openmpi/3.1
sbatch submit.bash